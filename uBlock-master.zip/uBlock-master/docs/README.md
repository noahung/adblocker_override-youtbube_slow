## uBlock Origin pages

HTML: <https://gorhill.github.io/uBlock/>.